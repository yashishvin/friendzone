README

COURSE : CS400
SEMESTER : Fall 2019
Project name : Social Network
Team Members :
Chokkarapu Sai Teja, LEC02 , and chokkarapu@wisc.edu
Lintong Han, LEC01, lhan48@wisc.edu
Zhihao Shu, LEC01, zshu9@wisc.edu
Lakshay, LEC02, lgoyal@wisc.edu

Chokkarapu Sai Teja and Lakshay in same xteam.

to the Grader:
->Created a Main Page and storing all the persons in the Set of the graph.
-> The Friends’ list is being refreshed every time when we click add.
-> hard coded for only ADD to show how the list is stored and updated,Remove button is not coded .
-> Canvas of the graph in scene-2 is not updated with the friends and center person but added to the graph in the backend.

